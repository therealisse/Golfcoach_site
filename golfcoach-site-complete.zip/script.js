const year = document.getElementById('year'); if(year){year.textContent = new Date().getFullYear();}

function showModal(kind){
  const c = document.getElementById('modal-content');
  const modal = document.getElementById('modal');
  const blocks = {
    expo: `
      <h3>Kör i Expo Go</h3>
      <ol>
        <li>Installera Node LTS + Expo Go på telefonen.</li>
        <li>Öppna projektmappen i terminalen och kör <code>npm install</code>.</li>
        <li>Starta dev-server: <code>npx expo start --tunnel -c</code></li>
        <li>Expo Go → Scan QR / Enter URL.</li>
      </ol>
    `,
    apk: `
      <h3>Bygg Android APK (EAS Build)</h3>
      <ol>
        <li><code>npm i -g eas-cli</code> och <code>eas login</code></li>
        <li>Skapa <code>eas.json</code> med buildType <code>apk</code>.</li>
        <li>Kör <code>eas build -p android --profile preview</code></li>
        <li>Öppna expo.dev-länken → Download APK → installera.</li>
      </ol>
    `,
    gh: `
      <h3>GitHub Pages deploy</h3>
      <ol>
        <li>Skapa repo på GitHub och ladda upp alla filer.</li>
        <li>Settings → Pages → Source: Deploy from branch (main, root).</li>
        <li>Vänta ~1–2 min → sidan live på <code>https://&lt;user&gt;.github.io/&lt;repo&gt;</code>.</li>
      </ol>
    `
  };
  c.innerHTML = blocks[kind] || '';
  modal.classList.remove('hidden');
}
function hideModal(){ document.getElementById('modal').classList.add('hidden'); }
