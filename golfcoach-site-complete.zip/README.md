# GolfCoach – komplett landningssida (GitHub Pages)
Denna ZIP innehåller en färdig **statisk sajt** för GolfCoach.

## Publicera på GitHub Pages
1. Skapa repo (t.ex. `golfcoach-site`) på GitHub.
2. Ladda upp alla filer från ZIP:en.
3. Settings → Pages → Source: Deploy from branch (main, root).
4. Vänta 1–2 min → sidan live på `https://<user>.github.io/<repo>`.

## Struktur
- `index.html` – startsida
- `styles.css` – styling
- `script.js` – modala guider
- `assets/` – ikon + mock-bild
- `docs/` – policy & villkor

> Obs: Detta är landningssidan. Själva mobilappen (Expo) ligger i ett separat repo.
